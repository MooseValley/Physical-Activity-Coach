/*
*/
public class PhysicalActivityCoach extends JFrame
{
}